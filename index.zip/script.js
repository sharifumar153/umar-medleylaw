/* ------------------------ JS ------------------------ */

var swiper = new Swiper(".mainSlider", {
  loop: true,
  speed: 1000,
  pagination: {
    el: ".swiper-pagination",
    dynamicBullets: true,
  },
  autoplay: {
    delay: 2000,
    disableOnInteraction: false,
  },
});

 /* ------------------------ Section-5 ------------------------ */ 
$(document).ready(function(){

  /* ------------------------ LogIn & SignUp ------------------------ */

$('#LogInButton').click(function(){
  $('#Loginform').toggleClass('active');
  $('.loginForm').show();
});

$('#register').click(function(){
  $('#SignUpform').toggleClass('active');
  $('.loginForm').hide();
});


$('.signButton').click(function(){
  $('#SignUpform').toggleClass('active');
  $('.loginForm').hide();
});


  /* ------------------------ FirstBox ------------------------ */

  $('.firstBox').on('mouseenter', function(){ 
    $('.firstBox').css('transform', 'translateY(20%)');
    $('.second').css('transform', 'translateY(-20%)');
    $('.third').css('transform', 'translateY(20%)');
    $('.fourth').css('transform', 'translateY(-20%)');
  });

  $('.firstBox').on('mouseleave', function(){ 
    $('.firstBox').css('transform', 'translateY(0%)');
    $('.second').css('transform', 'translateY(0%)');
    $('.third').css('transform', 'translateY(0%)');
    $('.fourth').css('transform', 'translateY(0%)');
  });

  /* ------------------------ second ------------------------ */

  $('.second').on('mouseenter', function(){
    $('.firstBox').css('transform', 'translateY(20%)');
    $('.second').css('transform', 'translateY(-20%)');
    $('.third').css('transform', 'translateY(20%)');
    $('.fourth').css('transform', 'translateY(-20%)');
  });

  $('.second').on('mouseleave', function(){
    $('.firstBox').css('transform', 'translateY(0%)');
    $('.second').css('transform', 'translateY(0%)');
    $('.third').css('transform', 'translateY(0%)');
    $('.fourth').css('transform', 'translateY(0%)');
  });

  /* ------------------------ third ------------------------ */

  $('.third').on('mouseenter', function(){
    $('.firstBox').css('transform', 'translateY(20%)');
    $('.second').css('transform', 'translateY(-20%)');
    $('.third').css('transform', 'translateY(20%)');
    $('.fourth').css('transform', 'translateY(-20%)');
  });

  $('.third').on('mouseleave', function(){
    $('.firstBox').css('transform', 'translateY(0%)');
    $('.second').css('transform', 'translateY(0%)');
    $('.third').css('transform', 'translateY(0%)');
    $('.fourth').css('transform', 'translateY(0%)');
  });

  /* ------------------------ fourth ------------------------ */

  $('.fourth').on('mouseenter', function(){
    $('.firstBox').css('transform', 'translateY(20%)');
    $('.second').css('transform', 'translateY(-20%)');
    $('.third').css('transform', 'translateY(20%)');
    $('.fourth').css('transform', 'translateY(-20%)');
  });

  $('.fourth').on('mouseleave', function(){
    $('.firstBox').css('transform', 'translateY(0%)');
    $('.second').css('transform', 'translateY(0%)');
    $('.third').css('transform', 'translateY(0%)');
    $('.fourth').css('transform', 'translateY(0%)');
  });


});
